"use client";

import { motion } from "framer-motion";
import { VerticalTimeline, VerticalTimelineElement } from "react-vertical-timeline-component";
import "react-vertical-timeline-component/style.min.css";
import { Briefcase, GraduationCap, Award } from "lucide-react";
import { useTheme } from "next-themes";
import { useEffect, useState } from "react";

const experiences = [
  {
    title: "Senior Frontend Developer",
    company: "Tech Company Inc.",
    date: "2022 - Present",
    description: "Leading the frontend development team, implementing modern UI/UX designs, and optimizing performance.",
    icon: <Briefcase />,
  },
  {
    title: "Frontend Developer",
    company: "Digital Agency XYZ",
    date: "2020 - 2022",
    description: "Built responsive web applications using React, Next.js, and TypeScript. Collaborated with UX designers and backend developers.",
    icon: <Briefcase />,
  },
  {
    title: "Web Developer Internship",
    company: "Startup ABC",
    date: "2019 - 2020",
    description: "Worked on various web development projects using HTML, CSS, and JavaScript. Gained experience in Agile methodologies.",
    icon: <Briefcase />,
  },
  {
    title: "Computer Science Degree",
    company: "University Name",
    date: "2015 - 2019",
    description: "Studied computer science with a focus on software engineering and web development.",
    icon: <GraduationCap />,
  }
];

export function Timeline() {
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [colors, setColors] = useState({
    background: "#1a1a1a",
    foreground: "#ffffff",
    primary: "#ffffff",
    secondary: "#2d2d2d",
    textColor: "#ffffff"
  });

  useEffect(() => {
    setMounted(true);
    
    if (resolvedTheme === "light") {
      setColors({
        background: "#ffffff",
        foreground: "#000000",
        primary: "#000000",
        secondary: "#f0f0f0",
        textColor: "#000000"
      });
    } else {
      setColors({
        background: "#1a1a1a",
        foreground: "#ffffff",
        primary: "#ffffff",
        secondary: "#2d2d2d",
        textColor: "#ffffff"
      });
    }
  }, [resolvedTheme]);

  if (!mounted) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
    >
      <VerticalTimeline lineColor={colors.secondary}>
        {experiences.map((exp, index) => (
          <VerticalTimelineElement
            key={index}
            contentStyle={{ 
              background: colors.secondary, 
              color: colors.textColor,
              boxShadow: "none",
              border: `1px solid ${resolvedTheme === "dark" ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.1)"}`,
              borderRadius: "0.5rem",
              padding: "1.5rem"
            }}
            contentArrowStyle={{ borderRight: `10px solid ${colors.secondary}` }}
            date={exp.date}
            iconStyle={{ 
              background: colors.background, 
              color: colors.primary,
              boxShadow: `0 0 0 4px ${colors.primary}`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center"
            }}
            icon={exp.icon}
          >
            <h3 className="font-bold text-lg">{exp.title}</h3>
            <h4 className="text-primary font-medium">{exp.company}</h4>
            <p className="mt-2 text-muted-foreground">{exp.description}</p>
          </VerticalTimelineElement>
        ))}
      </VerticalTimeline>
    </motion.div>
  );
}