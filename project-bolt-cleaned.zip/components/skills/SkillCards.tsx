"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import Image from "next/image";
import { staggerContainer, fadeIn } from "@/lib/animation";
import { Card, CardContent } from "@/components/ui/card";

interface Skill {
  name: string;
  level: number;
  icon: string;
}

interface SkillCardsProps {
  skills: Skill[];
  showLevel?: boolean;
}

export function SkillCards({ skills, showLevel = true }: SkillCardsProps) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  
  return (
    <motion.div
      variants={staggerContainer(0.1)}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-100px" }}
      className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"
    >
      {skills.map((skill, index) => (
        <motion.div
          key={skill.name}
          variants={fadeIn("up", index * 0.1)}
          whileHover={{ scale: 1.05 }}
          onMouseEnter={() => setHoveredIndex(index)}
          onMouseLeave={() => setHoveredIndex(null)}
        >
          <Card className="overflow-hidden h-full border border-border/50 hover:border-primary/50 transition-all duration-300">
            <CardContent className="p-6 flex flex-col items-center h-full">
              <div className="mb-4 relative w-16 h-16">
                <div className="absolute inset-0 flex items-center justify-center">
                  <Image
                    src={skill.icon}
                    alt={skill.name}
                    width={48}
                    height={48}
                    className="object-contain"
                  />
                </div>
                {hoveredIndex === index && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute inset-0 bg-primary/10 rounded-full"
                    style={{
                      boxShadow: "0 0 20px rgba(255,255,255,0.1)"
                    }}
                  />
                )}
              </div>
              
              <h3 className="text-lg font-semibold text-center mb-2">{skill.name}</h3>
              
              {showLevel && (
                <div className="w-full mt-auto">
                  <Progress value={skill.level} className="h-2" />
                  <p className="text-xs text-right mt-1 text-muted-foreground">
                    {skill.level}%
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </motion.div>
  );
}