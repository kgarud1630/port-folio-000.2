"use client";

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";

export default function AnimatedBackground() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [webGLError, setWebGLError] = useState(false);

  useEffect(() => {
    if (!containerRef.current) return;

    let renderer: THREE.WebGLRenderer;
    let cleanup: (() => void) | undefined;

    try {
      // Check WebGL support
      if (!THREE.WEBGL.isWebGLAvailable()) {
        throw new Error('WebGL is not available');
      }

      // Scene setup
      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(
        75,
        window.innerWidth / window.innerHeight,
        0.1,
        1000
      );

      renderer = new THREE.WebGLRenderer({ 
        alpha: true, 
        antialias: true,
        powerPreference: 'default', // Let the system choose the best power option
        failIfMajorPerformanceCaveat: false // Don't fail on performance issues
      });
      
      renderer.setSize(window.innerWidth, window.innerHeight);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      containerRef.current.appendChild(renderer.domElement);

      // Particle setup
      const particlesGeometry = new THREE.BufferGeometry();
      const particlesCount = 5000;
      
      const posArray = new Float32Array(particlesCount * 3);
      for (let i = 0; i < particlesCount * 3; i++) {
        posArray[i] = (Math.random() - 0.5) * 10;
      }
      
      particlesGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
      
      const particlesMaterial = new THREE.PointsMaterial({
        size: 0.005,
        color: new THREE.Color(0x8A2BE2),
        blending: THREE.AdditiveBlending,
        transparent: true,
      });
      
      const particlesMesh = new THREE.Points(particlesGeometry, particlesMaterial);
      scene.add(particlesMesh);

      camera.position.z = 3;

      // Mouse interaction
      let mouseX = 0;
      let mouseY = 0;
      
      function onDocumentMouseMove(event: MouseEvent) {
        mouseX = (event.clientX - window.innerWidth / 2) / 1000;
        mouseY = (event.clientY - window.innerHeight / 2) / 1000;
      }
      
      document.addEventListener('mousemove', onDocumentMouseMove);

      // Handle window resize
      const handleResize = () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
      };
      
      window.addEventListener('resize', handleResize);

      // Animation loop
      const animate = () => {
        requestAnimationFrame(animate);
        
        // Rotate the particles
        particlesMesh.rotation.x += 0.0003;
        particlesMesh.rotation.y += 0.0003;
        
        // Mouse interaction
        if (mouseX && mouseY) {
          particlesMesh.rotation.x += mouseY * 0.1;
          particlesMesh.rotation.y += mouseX * 0.1;
        }
        
        renderer.render(scene, camera);
      };
      
      animate();

      // Set up cleanup function
      cleanup = () => {
        if (containerRef.current) {
          containerRef.current.removeChild(renderer.domElement);
        }
        window.removeEventListener('resize', handleResize);
        document.removeEventListener('mousemove', onDocumentMouseMove);
        
        // Dispose of Three.js resources
        particlesGeometry.dispose();
        particlesMaterial.dispose();
        renderer.dispose();
      };

    } catch (error) {
      console.warn('WebGL initialization failed:', error);
      setWebGLError(true);
      
      // Clean up any partial initialization
      if (renderer && containerRef.current?.contains(renderer.domElement)) {
        containerRef.current.removeChild(renderer.domElement);
      }
      
      return;
    }

    // Return cleanup function
    return cleanup;
  }, []);

  // If WebGL failed, render nothing (or you could render a fallback background)
  if (webGLError) {
    return (
      <div 
        className="absolute inset-0 -z-10 bg-gradient-to-br from-purple-900 to-black"
        aria-hidden="true"
      ></div>
    );
  }

  return (
    <div 
      ref={containerRef} 
      className="absolute inset-0 -z-10"
      aria-hidden="true"
    ></div>
  );
}