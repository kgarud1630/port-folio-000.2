"use client";

import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, MapPin, Phone, Github, Linkedin, Twitter } from "lucide-react";
import { fadeIn } from "@/lib/animation";

export function ContactInfo() {
  return (
    <motion.div
      variants={fadeIn("right", 0.3)}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true }}
    >
      <div className="space-y-6">
        <div>
          <h3 className="text-2xl font-bold mb-6">Get In Touch</h3>
          <p className="text-muted-foreground mb-8">
            I'm currently available for freelance work, full-time positions, or consulting opportunities. Feel free to reach out if you have a project in mind or just want to connect.
          </p>
        </div>
        
        <div className="space-y-4">
          <Card className="border-border/50">
            <CardContent className="p-4 flex items-center space-x-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Mail className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h4 className="text-sm font-medium">Email</h4>
                <p className="text-muted-foreground">contact@example.com</p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-border/50">
            <CardContent className="p-4 flex items-center space-x-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <MapPin className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h4 className="text-sm font-medium">Location</h4>
                <p className="text-muted-foreground">San Francisco, CA</p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-border/50">
            <CardContent className="p-4 flex items-center space-x-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Phone className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h4 className="text-sm font-medium">Phone</h4>
                <p className="text-muted-foreground">(123) 456-7890</p>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <h4 className="text-lg font-semibold mb-4">Follow Me</h4>
          <div className="flex space-x-3">
            <Button variant="outline" size="icon" asChild>
              <a href="https://github.com" target="_blank" rel="noreferrer" aria-label="GitHub">
                <Github className="h-5 w-5" />
              </a>
            </Button>
            <Button variant="outline" size="icon" asChild>
              <a href="https://linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
                <Linkedin className="h-5 w-5" />
              </a>
            </Button>
            <Button variant="outline" size="icon" asChild>
              <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
                <Twitter className="h-5 w-5" />
              </a>
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}