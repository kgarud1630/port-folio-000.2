"use client";

import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { ExternalLink, Calendar, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { fadeIn } from "@/lib/animation";
import { Certificate } from "@/lib/data/certificates";

interface CertificateCardProps {
  certificate: Certificate;
  index: number;
}

export function CertificateCard({ certificate, index }: CertificateCardProps) {
  return (
    <motion.div
      variants={fadeIn("up", 0.1 * index)}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-100px" }}
      whileHover={{ y: -5, transition: { duration: 0.3 } }}
      className="h-full"
    >
      <Card className="h-full bg-card hover:shadow-lg transition-all duration-300 overflow-hidden border-border/50 hover:border-primary/50">
        <CardContent className="p-6 flex flex-col h-full">
          <div className="flex items-start justify-between mb-4">
            <div className="mr-4 bg-primary/10 p-3 rounded-full">
              <Award className="h-6 w-6 text-primary" />
            </div>
            {certificate.featured && (
              <span className="inline-block px-2.5 py-0.5 bg-primary/10 text-primary rounded-full text-xs font-medium">
                Featured
              </span>
            )}
          </div>
          
          <h3 className="text-lg font-semibold mb-2">{certificate.title}</h3>
          <p className="text-primary font-medium text-sm mb-1">{certificate.issuer}</p>
          
          <div className="flex items-center text-muted-foreground text-sm mb-4">
            <Calendar className="h-4 w-4 mr-1.5" />
            <span>{certificate.date}</span>
          </div>
          
          <p className="text-muted-foreground text-sm mb-6 flex-grow">{certificate.description}</p>
          
          {certificate.credentialUrl && (
            <Button variant="outline" size="sm" className="mt-auto" asChild>
              <a href={certificate.credentialUrl} target="_blank" rel="noreferrer">
                <ExternalLink className="h-4 w-4 mr-2" /> View Credential
              </a>
            </Button>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}