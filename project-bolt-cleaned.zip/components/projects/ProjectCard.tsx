"use client";

import { motion } from "framer-motion";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, Github, Info } from "lucide-react";
import Image from "next/image";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Project } from "@/lib/data/projects";

interface ProjectCardProps {
  project: Project;
  index: number;
}

export default function ProjectCard({ project, index }: ProjectCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="overflow-hidden h-full flex flex-col bg-card hover:shadow-lg transition-all duration-300 border-border/50 hover:border-primary/50">
        <AspectRatio ratio={16/9} className="bg-muted relative group">
          <Image
            src={project.image}
            alt={project.title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="flex space-x-3">
              {project.liveUrl && (
                <Button size="sm\" asChild>
                  <a href={project.liveUrl} target="_blank" rel="noreferrer">
                    <ExternalLink className="h-4 w-4 mr-2" /> Live
                  </a>
                </Button>
              )}
              {project.githubUrl && (
                <Button size="sm" variant="outline" asChild>
                  <a href={project.githubUrl} target="_blank" rel="noreferrer">
                    <Github className="h-4 w-4 mr-2" /> Code
                  </a>
                </Button>
              )}
            </div>
          </div>
        </AspectRatio>
        
        <CardContent className="p-6 flex-grow">
          <div className="flex items-start justify-between mb-2">
            <h3 className="text-xl font-bold">{project.title}</h3>
            <span className="inline-block px-2 py-1 text-xs font-medium bg-primary/10 text-primary rounded-md">
              {project.category}
            </span>
          </div>
          <p className="text-muted-foreground mb-4 line-clamp-2">{project.description}</p>
          <div className="flex flex-wrap gap-1.5 mt-2">
            {project.technologies.map((tech, i) => (
              <span key={i} className="px-2 py-1 bg-secondary text-secondary-foreground text-xs rounded-md">
                {tech}
              </span>
            ))}
          </div>
        </CardContent>
        
        <CardFooter className="px-6 pb-6 pt-0">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full">
                <Info className="h-4 w-4 mr-2" /> Project Details
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-xl font-bold">{project.title}</DialogTitle>
                <DialogDescription className="text-muted-foreground">
                  {project.category} • {project.date}
                </DialogDescription>
              </DialogHeader>
              
              <AspectRatio ratio={16/9} className="bg-muted mt-4 overflow-hidden rounded-lg">
                <Image
                  src={project.image}
                  alt={project.title}
                  fill
                  className="object-cover"
                />
              </AspectRatio>
              
              <div className="space-y-4 mt-4">
                <div>
                  <h4 className="font-semibold mb-1">Project Overview</h4>
                  <p className="text-muted-foreground text-sm">{project.description}</p>
                </div>
                
                {project.longDescription && (
                  <div>
                    <h4 className="font-semibold mb-1">Challenge & Solution</h4>
                    <p className="text-muted-foreground text-sm">{project.longDescription}</p>
                  </div>
                )}
                
                <div>
                  <h4 className="font-semibold mb-2">Technologies Used</h4>
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech, i) => (
                      <span key={i} className="px-2 py-1 bg-secondary text-secondary-foreground text-xs rounded-md">
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div className="flex space-x-3 pt-4">
                  {project.liveUrl && (
                    <Button asChild>
                      <a href={project.liveUrl} target="_blank" rel="noreferrer">
                        <ExternalLink className="h-4 w-4 mr-2" /> Live Demo
                      </a>
                    </Button>
                  )}
                  {project.githubUrl && (
                    <Button variant="outline" asChild>
                      <a href={project.githubUrl} target="_blank" rel="noreferrer">
                        <Github className="h-4 w-4 mr-2" /> View Code
                      </a>
                    </Button>
                  )}
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </CardFooter>
      </Card>
    </motion.div>
  );
}