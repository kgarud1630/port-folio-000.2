"use client";

import { motion } from "framer-motion";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { CalendarDays, Clock, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import Link from "next/link";
import { Post } from "@/lib/blog";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { fadeIn } from "@/lib/animation";

interface BlogCardProps {
  post: Post;
  index: number;
}

export function BlogCard({ post, index }: BlogCardProps) {
  return (
    <motion.div
      variants={fadeIn("up", 0.1 * index)}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-100px" }}
      className="h-full"
    >
      <Card className="h-full overflow-hidden flex flex-col border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-lg">
        <AspectRatio ratio={16/9} className="bg-muted relative">
          <Link href={`/blog/${post.slug}`} className="group">
            <Image
              src={post.coverImage}
              alt={post.title}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-105"
            />
          </Link>
        </AspectRatio>
        
        <CardContent className="p-6 flex-grow">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Avatar className="h-8 w-8">
                <AvatarImage src="https://images.pexels.com/photos/927022/pexels-photo-927022.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" alt="Author" />
                <AvatarFallback>YN</AvatarFallback>
              </Avatar>
              <span className="text-sm text-muted-foreground">Your Name</span>
            </div>
            <span className="text-xs px-2.5 py-1 bg-primary/10 text-primary rounded-full">
              {post.category}
            </span>
          </div>
          
          <Link href={`/blog/${post.slug}`} className="group">
            <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
              {post.title}
            </h3>
          </Link>
          
          <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
            {post.excerpt}
          </p>
          
          <div className="flex items-center text-xs text-muted-foreground space-x-4">
            <div className="flex items-center">
              <CalendarDays className="h-3.5 w-3.5 mr-1.5" />
              <span>{post.date}</span>
            </div>
            <div className="flex items-center">
              <Clock className="h-3.5 w-3.5 mr-1.5" />
              <span>{post.readingTime}</span>
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="px-6 pb-6 pt-0">
          <Button variant="ghost" className="p-0 h-auto" asChild>
            <Link href={`/blog/${post.slug}`}>
              Read More <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}