import { SectionHeader } from "@/components/ui/section-header";
import { CertificateCard } from "@/components/certifications/CertificateCard";
import { certificates } from "@/lib/data/certificates";

export const metadata = {
  title: "Certifications | Professional Portfolio",
  description: "View my professional certifications and educational achievements."
};

export default function CertificationsPage() {
  return (
    <div className="container mx-auto px-4 pt-24 pb-16">
      <SectionHeader 
        title="Certifications" 
        subtitle="Professional certifications and courses I've completed"
      />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {certificates.map((certificate, index) => (
          <CertificateCard 
            key={index} 
            certificate={certificate} 
            index={index} 
          />
        ))}
      </div>
    </div>
  );
}