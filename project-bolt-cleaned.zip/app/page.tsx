import HeroSection from "@/components/home/HeroSection";
import AnimatedBackground from "@/components/home/AnimatedBackground";
import { SectionHeader } from "@/components/ui/section-header";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function Home() {
  return (
    <div className="relative">
      <AnimatedBackground />
      <HeroSection />
      
      <section id="featured" className="py-24 px-4 container mx-auto">
        <SectionHeader 
          title="Featured Work" 
          subtitle="Some of my recent projects that showcase my skills and expertise"
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="overflow-hidden group hover:shadow-lg transition-all duration-300">
              <div className="aspect-video bg-muted relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                  <div className="space-x-2">
                    <Button size="sm" variant="secondary" asChild>
                      <Link href="#">Live Demo</Link>
                    </Button>
                    <Button size="sm" variant="outline" asChild>
                      <a href="#" target="_blank" rel="noreferrer">GitHub</a>
                    </Button>
                  </div>
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-2">Project {i}</h3>
                <p className="text-muted-foreground mb-4">
                  A brief description of project {i} and the technologies used.
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <span className="px-2.5 py-0.5 bg-primary/10 text-primary rounded-full text-xs font-medium">
                    React
                  </span>
                  <span className="px-2.5 py-0.5 bg-primary/10 text-primary rounded-full text-xs font-medium">
                    TypeScript
                  </span>
                  <span className="px-2.5 py-0.5 bg-primary/10 text-primary rounded-full text-xs font-medium">
                    Tailwind CSS
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <Button asChild>
            <Link href="/projects">
              View All Projects <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>
    </div>
  );
}