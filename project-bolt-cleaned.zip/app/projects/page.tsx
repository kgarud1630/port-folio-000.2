import { SectionHeader } from "@/components/ui/section-header";
import ProjectCard from "@/components/projects/ProjectCard";
import { projects } from "@/lib/data/projects";
import { Button } from "@/components/ui/button";
import { Download, Github } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export const metadata = {
  title: "Projects | Professional Portfolio",
  description: "Explore my portfolio of projects across various technologies and domains."
};

export default function ProjectsPage() {
  // Get unique categories
  const categories = Array.from(new Set(projects.map(project => project.category)));

  return (
    <div className="container mx-auto px-4 pt-24 pb-16">
      <SectionHeader 
        title="My Projects" 
        subtitle="A showcase of my work, personal projects and contributions"
      />
      
      <div className="flex justify-center mb-8">
        <div className="flex space-x-4">
          <Button variant="outline" asChild>
            <a href="https://github.com" target="_blank" rel="noreferrer">
              <Github className="mr-2 h-5 w-5" /> View GitHub Profile
            </a>
          </Button>
          <Button variant="outline">
            <Download className="mr-2 h-5 w-5" /> Download Resume
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="all" className="max-w-5xl mx-auto">
        <TabsList className="grid grid-cols-2 md:grid-cols-6 mb-12">
          <TabsTrigger value="all">All</TabsTrigger>
          {categories.map((category) => (
            <TabsTrigger key={category} value={category}>{category}</TabsTrigger>
          ))}
        </TabsList>
        
        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <ProjectCard key={index} project={project} index={index} />
            ))}
          </div>
        </TabsContent>
        
        {categories.map((category) => (
          <TabsContent key={category} value={category}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {projects
                .filter(project => project.category === category)
                .map((project, index) => (
                  <ProjectCard key={index} project={project} index={index} />
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}