import Link from "next/link";
import { SectionHeader } from "@/components/ui/section-header";
import { BlogCard } from "@/components/blog/BlogCard";
import { getPosts } from "@/lib/blog";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export const metadata = {
  title: "Blog | Professional Portfolio",
  description: "Read my latest articles on web development, design, and technology."
};

export default function BlogPage() {
  const posts = getPosts();

  return (
    <div className="container mx-auto px-4 pt-24 pb-16">
      <SectionHeader 
        title="Blog" 
        subtitle="Thoughts, learnings, and insights about web development and design"
      />
      
      <div className="max-w-md mx-auto mb-12">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input 
            placeholder="Search articles..." 
            className="pl-10 bg-background"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
        {posts.map((post, index) => (
          <BlogCard key={post.slug} post={post} index={index} />
        ))}
      </div>
      
      <div className="text-center">
        <Button variant="outline">Load More Articles</Button>
      </div>
    </div>
  );
}