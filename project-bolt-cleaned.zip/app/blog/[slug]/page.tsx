import { SectionHeader } from "@/components/ui/section-header";
import { Button } from "@/components/ui/button";
import { ChevronLeft, CalendarDays, Clock, User } from "lucide-react";
import { getPostBySlug } from "@/lib/blog";
import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}) {
  const post = getPostBySlug(params.slug);
  
  if (!post) {
    return {
      title: "Blog Post Not Found",
      description: "The requested blog post could not be found."
    };
  }
  
  return {
    title: `${post.title} | Professional Portfolio`,
    description: post.excerpt,
    openGraph: {
      title: post.title,
      description: post.excerpt,
      type: "article",
      publishedTime: post.date,
      images: [{ url: post.coverImage }],
    },
  };
}

export default function BlogPostPage({
  params,
}: {
  params: { slug: string };
}) {
  const post = getPostBySlug(params.slug);
  
  if (!post) {
    notFound();
  }

  // In a real app, this would parse markdown to HTML
  // For now, let's use some placeholder content
  const content = `
    <p>This is a placeholder for the blog post content. In a real implementation, this would be generated from markdown or fetched from a CMS like Contentful or Sanity.</p>
    
    <p>The content would include rich text formatting, code blocks, images, and other media elements that would be rendered appropriately.</p>
    
    <h2>Main Section</h2>
    
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget aliquam ultricies, nunc nisl aliquet nunc, eget aliquam nisl nunc vel nisl. Nullam euismod, nisl eget aliquam ultricies, nunc nisl aliquet nunc, eget aliquam nisl nunc vel nisl.</p>
    
    <h3>Subsection</h3>
    
    <p>Nullam euismod, nisl eget aliquam ultricies, nunc nisl aliquet nunc, eget aliquam nisl nunc vel nisl. Nullam euismod, nisl eget aliquam ultricies, nunc nisl aliquet nunc, eget aliquam nisl nunc vel nisl.</p>
    
    <ul>
      <li>List item 1</li>
      <li>List item 2</li>
      <li>List item 3</li>
    </ul>
    
    <h2>Conclusion</h2>
    
    <p>Nullam euismod, nisl eget aliquam ultricies, nunc nisl aliquet nunc, eget aliquam nisl nunc vel nisl. Nullam euismod, nisl eget aliquam ultricies, nunc nisl aliquet nunc, eget aliquam nisl nunc vel nisl.</p>
  `;

  return (
    <div className="container mx-auto px-4 pt-24 pb-16">
      <div className="max-w-4xl mx-auto">
        <Button variant="ghost" className="mb-8" asChild>
          <Link href="/blog">
            <ChevronLeft className="mr-2 h-4 w-4" /> Back to Blog
          </Link>
        </Button>
        
        <div className="mb-12">
          <div className="flex flex-wrap gap-4 items-center justify-between mb-6">
            <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium">
              {post.category}
            </span>
            <div className="flex items-center text-sm text-muted-foreground space-x-4">
              <div className="flex items-center">
                <CalendarDays className="h-4 w-4 mr-2" />
                <span>{post.date}</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-2" />
                <span>{post.readingTime}</span>
              </div>
              <div className="flex items-center">
                <User className="h-4 w-4 mr-2" />
                <span>Your Name</span>
              </div>
            </div>
          </div>
          
          <h1 className="text-3xl md:text-4xl font-bold mb-6">{post.title}</h1>
          <p className="text-xl text-muted-foreground mb-8">{post.excerpt}</p>
        </div>
        
        <div className="relative aspect-video mb-12 rounded-lg overflow-hidden">
          <Image
            src={post.coverImage}
            alt={post.title}
            fill
            className="object-cover"
            priority
          />
        </div>
        
        <article className="prose prose-lg dark:prose-invert max-w-none mb-12">
          <div dangerouslySetInnerHTML={{ __html: content }} />
        </article>
        
        <div className="border-t border-border pt-8">
          <h3 className="text-xl font-bold mb-4">Share this article</h3>
          <div className="flex space-x-4">
            <Button variant="outline" size="sm">Share on Twitter</Button>
            <Button variant="outline" size="sm">Share on LinkedIn</Button>
            <Button variant="outline" size="sm">Copy Link</Button>
          </div>
        </div>
      </div>
    </div>
  );
}