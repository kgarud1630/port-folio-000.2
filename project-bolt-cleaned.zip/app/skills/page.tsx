import { SectionHeader } from "@/components/ui/section-header";
import { SkillCards } from "@/components/skills/SkillCards";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export const metadata = {
  title: "Skills | Professional Portfolio",
  description: "Explore my technical skills, tools, and technologies I work with."
};

export default function SkillsPage() {
  return (
    <div className="container mx-auto px-4 pt-24 pb-16">
      <SectionHeader 
        title="My Skills" 
        subtitle="Technologies and tools I've worked with"
      />
      
      <Tabs defaultValue="frontend" className="max-w-4xl mx-auto">
        <TabsList className="grid grid-cols-4 mb-12">
          <TabsTrigger value="frontend">Frontend</TabsTrigger>
          <TabsTrigger value="backend">Backend</TabsTrigger>
          <TabsTrigger value="tools">Tools</TabsTrigger>
          <TabsTrigger value="soft">Soft Skills</TabsTrigger>
        </TabsList>
        
        <TabsContent value="frontend">
          <SkillCards
            skills={[
              { name: "React", level: 90, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" },
              { name: "Next.js", level: 85, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nextjs/nextjs-original.svg" },
              { name: "TypeScript", level: 85, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-original.svg" },
              { name: "JavaScript", level: 95, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" },
              { name: "HTML5", level: 95, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" },
              { name: "CSS3", level: 90, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" },
              { name: "Tailwind CSS", level: 90, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/tailwindcss/tailwindcss-plain.svg" },
              { name: "Redux", level: 80, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/redux/redux-original.svg" },
              { name: "Framer Motion", level: 75, icon: "https://seeklogo.com/images/F/framer-motion-logo-DA1E33CAA1-seeklogo.com.png" }
            ]}
          />
        </TabsContent>
        
        <TabsContent value="backend">
          <SkillCards
            skills={[
              { name: "Node.js", level: 85, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg" },
              { name: "Express", level: 80, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/express/express-original.svg" },
              { name: "PostgreSQL", level: 75, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-original.svg" },
              { name: "MongoDB", level: 80, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original.svg" },
              { name: "Firebase", level: 85, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/firebase/firebase-plain.svg" },
              { name: "GraphQL", level: 70, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/graphql/graphql-plain.svg" },
              { name: "REST API", level: 90, icon: "https://www.svgrepo.com/show/374111/swagger.svg" },
              { name: "Prisma", level: 75, icon: "https://www.svgrepo.com/show/373776/light-prisma.svg" }
            ]}
          />
        </TabsContent>
        
        <TabsContent value="tools">
          <SkillCards
            skills={[
              { name: "Git", level: 90, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg" },
              { name: "Docker", level: 75, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/docker/docker-original.svg" },
              { name: "VS Code", level: 95, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg" },
              { name: "Figma", level: 85, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/figma/figma-original.svg" },
              { name: "Jest", level: 80, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/jest/jest-plain.svg" },
              { name: "GitHub", level: 90, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/github/github-original.svg" },
              { name: "Webpack", level: 75, icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/webpack/webpack-original.svg" },
              { name: "Vercel", level: 85, icon: "https://www.svgrepo.com/show/354512/vercel.svg" }
            ]}
          />
        </TabsContent>
        
        <TabsContent value="soft">
          <SkillCards
            skills={[
              { name: "Problem Solving", level: 95, icon: "https://www.svgrepo.com/show/422458/bulb-creativity-idea.svg" },
              { name: "Communication", level: 90, icon: "https://www.svgrepo.com/show/489396/conversation.svg" },
              { name: "Teamwork", level: 95, icon: "https://www.svgrepo.com/show/489680/group.svg" },
              { name: "Time Management", level: 85, icon: "https://www.svgrepo.com/show/489834/clock.svg" },
              { name: "Adaptability", level: 90, icon: "https://www.svgrepo.com/show/489683/refresh.svg" },
              { name: "Leadership", level: 85, icon: "https://www.svgrepo.com/show/506817/target.svg" },
              { name: "Critical Thinking", level: 90, icon: "https://www.svgrepo.com/show/470489/brain.svg" },
              { name: "Creativity", level: 90, icon: "https://www.svgrepo.com/show/501780/palette.svg" }
            ]}
            showLevel={false}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}