import { SectionHeader } from "@/components/ui/section-header";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Timeline } from "@/components/about/Timeline";

export const metadata = {
  title: "About | Professional Portfolio",
  description: "Learn about my background, journey, and the skills I've developed over the years."
};

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 pt-24 pb-16">
      <SectionHeader 
        title="About Me" 
        subtitle="Get to know me, my background, and my journey"
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mb-20">
        <div className="lg:col-span-2 order-2 lg:order-1">
          <h3 className="text-2xl font-bold mb-4">Hello, I'm Your Name</h3>
          <div className="space-y-4 text-muted-foreground">
            <p>
              I'm a passionate developer with expertise in building modern web applications using cutting-edge technologies. My journey in tech started over 5 years ago, and I've been crafting digital experiences ever since.
            </p>
            <p>
              I specialize in front-end development with React, Next.js, and TypeScript, but I'm also proficient in back-end technologies like Node.js and databases such as PostgreSQL and MongoDB.
            </p>
            <p>
              What drives me is solving complex problems and turning ideas into reality through clean, efficient code. I believe in continuous learning and staying updated with the latest industry trends and best practices.
            </p>
            <p>
              When I'm not coding, you can find me exploring new technologies, contributing to open-source projects, or sharing my knowledge through blog posts and mentoring.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            {["Problem Solving", "Team Collaboration", "Clean Code", "User-Centric Design"].map((item, index) => (
              <Card key={index} className="bg-primary/5 border-none">
                <CardContent className="p-4 text-center">
                  <p className="text-sm font-medium">{item}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        
        <div className="order-1 lg:order-2 flex justify-center">
          <div className="relative">
            <Avatar className="h-64 w-64">
              <AvatarImage src="https://images.pexels.com/photos/927022/pexels-photo-927022.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" alt="Profile" />
              <AvatarFallback>YN</AvatarFallback>
            </Avatar>
            <div className="absolute -bottom-4 -right-4 bg-primary text-primary-foreground px-4 py-2 rounded-md shadow-lg">
              <p className="text-sm font-medium">5+ Years Experience</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-20">
        <h3 className="text-2xl font-bold mb-8 text-center">My Journey</h3>
        <Timeline />
      </div>
      
      <div>
        <h3 className="text-2xl font-bold mb-8 text-center">Education & Achievements</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[
            {
              title: "Bachelor of Science in Computer Science",
              institution: "University Name",
              year: "2015-2019",
              description: "Graduated with honors, focusing on software engineering and web development."
            },
            {
              title: "Full-Stack Web Development Bootcamp",
              institution: "Coding Academy",
              year: "2020",
              description: "Intensive 12-week program covering modern web development technologies."
            }
          ].map((item, index) => (
            <Card key={index} className="overflow-hidden">
              <CardContent className="p-6">
                <h4 className="text-xl font-bold mb-2">{item.title}</h4>
                <p className="text-primary font-medium mb-1">{item.institution}</p>
                <p className="text-sm text-muted-foreground mb-4">{item.year}</p>
                <p className="text-muted-foreground">{item.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}