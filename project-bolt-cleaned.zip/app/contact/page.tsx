import { SectionHeader } from "@/components/ui/section-header";
import ContactForm from "@/components/contact/ContactForm";
import { ContactInfo } from "@/components/contact/ContactInfo";

export const metadata = {
  title: "Contact | Professional Portfolio",
  description: "Get in touch with me for collaboration, job opportunities, or just to say hello."
};

export default function ContactPage() {
  return (
    <div className="container mx-auto px-4 pt-24 pb-16">
      <SectionHeader 
        title="Contact Me" 
        subtitle="Let's get in touch. Fill out the form below or use my contact information."
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
        <ContactInfo />
        <ContactForm />
      </div>
    </div>
  );
}