export interface Post {
  slug: string;
  title: string;
  date: string;
  coverImage: string;
  excerpt: string;
  category: string;
  readingTime: string;
  content?: string;
}

export function getPosts(): Post[] {
  // In a real implementation, this would fetch from a CMS or markdown files
  return [
    {
      slug: "getting-started-with-nextjs",
      title: "Getting Started with Next.js 13: App Router and Server Components",
      date: "April 15, 2023",
      coverImage: "https://images.pexels.com/photos/11035471/pexels-photo-11035471.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      excerpt: "Learn how to build modern applications with Next.js 13, leveraging the new App Router and Server Components for optimal performance.",
      category: "Web Development",
      readingTime: "6 min read",
    },
    {
      slug: "mastering-typescript",
      title: "Mastering TypeScript: Advanced Types and Patterns",
      date: "March 22, 2023",
      coverImage: "https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      excerpt: "Deep dive into TypeScript's advanced type system features and design patterns for large-scale applications.",
      category: "Programming",
      readingTime: "8 min read",
    },
    {
      slug: "framer-motion-animations",
      title: "Creating Stunning UI Animations with Framer Motion",
      date: "February 10, 2023",
      coverImage: "https://images.pexels.com/photos/7005442/pexels-photo-7005442.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      excerpt: "Learn how to implement beautiful, physics-based animations in your React applications using Framer Motion.",
      category: "UI/UX",
      readingTime: "5 min read",
    },
    {
      slug: "tailwind-css-best-practices",
      title: "Tailwind CSS Best Practices for Scalable Applications",
      date: "January 28, 2023",
      coverImage: "https://images.pexels.com/photos/5483071/pexels-photo-5483071.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      excerpt: "Discover best practices for organizing and scaling your Tailwind CSS projects, from component architecture to custom plugins.",
      category: "CSS",
      readingTime: "7 min read",
    },
    {
      slug: "optimizing-react-performance",
      title: "Optimizing React Application Performance",
      date: "December 15, 2022",
      coverImage: "https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      excerpt: "Practical strategies to identify and resolve performance bottlenecks in React applications.",
      category: "Web Development",
      readingTime: "9 min read",
    },
    {
      slug: "api-design-patterns",
      title: "REST API Design Patterns and Best Practices",
      date: "November 5, 2022",
      coverImage: "https://images.pexels.com/photos/6444/pencil-typography-black-design.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      excerpt: "An exploration of RESTful API design patterns, authentication strategies, and documentation approaches.",
      category: "Backend",
      readingTime: "10 min read",
    }
  ];
}

export function getPostBySlug(slug: string): Post | undefined {
  return getPosts().find(post => post.slug === slug);
}