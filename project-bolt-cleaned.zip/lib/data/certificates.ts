export interface Certificate {
  title: string;
  issuer: string;
  date: string;
  description: string;
  credentialUrl?: string;
  featured?: boolean;
}

export const certificates: Certificate[] = [
  {
    title: "Full-Stack Web Development",
    issuer: "Udacity",
    date: "December 2022",
    description: "Comprehensive program covering modern web development technologies including React, Node.js, and database design.",
    credentialUrl: "https://example.com/credential",
    featured: true
  },
  {
    title: "React - The Complete Guide",
    issuer: "Udemy",
    date: "October 2022",
    description: "In-depth course on React, covering Hooks, Redux, Next.js, and modern React patterns and best practices.",
    credentialUrl: "https://example.com/credential",
  },
  {
    title: "TypeScript Advanced Concepts",
    issuer: "Frontend Masters",
    date: "August 2022",
    description: "Advanced TypeScript programming with focus on type systems, generics, and integration with React.",
    credentialUrl: "https://example.com/credential",
  },
  {
    title: "UI/UX Design Fundamentals",
    issuer: "Interaction Design Foundation",
    date: "June 2022",
    description: "Principles of user interface and experience design, including user research, wireframing, and prototyping.",
    credentialUrl: "https://example.com/credential",
  },
  {
    title: "Advanced JavaScript Concepts",
    issuer: "Udemy",
    date: "March 2022",
    description: "Deep dive into JavaScript, covering closures, prototypal inheritance, async programming, and functional concepts.",
    credentialUrl: "https://example.com/credential",
  },
  {
    title: "AWS Certified Developer",
    issuer: "Amazon Web Services",
    date: "January 2022",
    description: "Professional certification validating expertise in developing, deploying, and debugging cloud-based applications using AWS.",
    credentialUrl: "https://example.com/credential",
    featured: true
  }
];