export interface Project {
  title: string;
  description: string;
  longDescription?: string;
  image: string;
  technologies: string[];
  category: string;
  date: string;
  githubUrl?: string;
  liveUrl?: string;
}

export const projects: Project[] = [
  {
    title: "E-Commerce Platform",
    description: "A modern e-commerce platform built with Next.js, featuring product listings, cart management, and Stripe payment integration.",
    longDescription: "This project was designed to showcase a full-featured e-commerce solution with a focus on performance and user experience. I implemented SSR for fast initial loads, client-side transitions for smooth navigation, and a responsive design that works flawlessly on all devices.",
    image: "https://images.pexels.com/photos/5632402/pexels-photo-5632402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    technologies: ["Next.js", "TypeScript", "Tailwind CSS", "Stripe", "Supabase"],
    category: "Web App",
    date: "Jan 2023",
    githubUrl: "https://github.com",
    liveUrl: "https://example.com",
  },
  {
    title: "Task Management Dashboard",
    description: "A comprehensive task management application with drag-and-drop functionality, user authentication, and real-time updates.",
    longDescription: "The Task Management Dashboard was built to solve the problem of team coordination across multiple projects. It features real-time updates using WebSockets, a drag-and-drop interface for task management, and comprehensive reporting features.",
    image: "https://images.pexels.com/photos/2115217/pexels-photo-2115217.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    technologies: ["React", "Node.js", "Express", "MongoDB", "Socket.io"],
    category: "Web App",
    date: "Oct 2022",
    githubUrl: "https://github.com",
    liveUrl: "https://example.com",
  },
  {
    title: "Finance Tracker App",
    description: "A personal finance application allowing users to track expenses, set budgets, and visualize spending patterns.",
    longDescription: "The Finance Tracker App was developed to help users gain better control over their personal finances. It includes features like expense categorization, budget setting with alerts, and data visualization to understand spending habits over time.",
    image: "https://images.pexels.com/photos/4386366/pexels-photo-4386366.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    technologies: ["React Native", "Firebase", "Chart.js", "Redux"],
    category: "Mobile App",
    date: "May 2022",
    githubUrl: "https://github.com",
  },
  {
    title: "AI Content Generator",
    description: "An AI-powered application that helps users generate blog posts, social media content, and marketing copy.",
    longDescription: "This project integrates with OpenAI's API to provide AI-generated content solutions for marketers and content creators. It features multiple content templates, tone adjustment options, and an editor for fine-tuning the generated content.",
    image: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    technologies: ["Next.js", "OpenAI API", "Tailwind CSS", "TypeScript"],
    category: "Web App",
    date: "Aug 2022",
    githubUrl: "https://github.com",
    liveUrl: "https://example.com",
  },
  {
    title: "Weather Dashboard",
    description: "A real-time weather application with interactive maps, forecasts, and location-based services.",
    longDescription: "The Weather Dashboard combines multiple APIs to provide comprehensive weather data with an intuitive interface. Features include hourly and 7-day forecasts, severe weather alerts, and historical weather data visualization.",
    image: "https://images.pexels.com/photos/3608311/pexels-photo-3608311.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    technologies: ["React", "OpenWeather API", "Mapbox", "CSS Modules"],
    category: "Web App",
    date: "Mar 2022",
    githubUrl: "https://github.com",
    liveUrl: "https://example.com",
  },
  {
    title: "Fitness Tracking Application",
    description: "A mobile fitness tracker with workout plans, progress tracking, and health metrics visualization.",
    longDescription: "Developed for fitness enthusiasts, this app helps users track their workouts, set goals, and monitor progress. It includes custom workout creation, exercise demonstration videos, and integration with health devices through HealthKit/Google Fit.",
    image: "https://images.pexels.com/photos/841130/pexels-photo-841130.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    technologies: ["React Native", "Firebase", "Redux", "HealthKit/Google Fit APIs"],
    category: "Mobile App",
    date: "Feb 2022",
    githubUrl: "https://github.com",
  }
];